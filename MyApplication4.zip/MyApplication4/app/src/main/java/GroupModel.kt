data class GroupModel(val groupname: String, val memberscount: String) {

}
