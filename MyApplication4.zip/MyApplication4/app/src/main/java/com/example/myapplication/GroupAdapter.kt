package com.example.myapplication
import GroupModel
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView

class GroupAdapter(private val groupList:List<GroupModel>) :
    RecyclerView.Adapter<GroupAdapter.GroupViewHolder>() {


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): GroupViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.activity_item_group_card, parent, false)
        return GroupViewHolder(view)
    }


    override fun onBindViewHolder(holder: GroupViewHolder, position: Int) {
        val currentGroup = groupList[position]
        holder.tvGroupName.text = currentGroup.groupname
        holder.tvMembersCount.text = currentGroup.memberscount


        holder.btnJoinGroup.setOnClickListener {
            Toast.makeText(holder.itemView.context, "Joined ${currentGroup.groupname}!", Toast.LENGTH_SHORT).show()
        }
    }

    override fun getItemCount(): Int = groupList.size

    class GroupViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvGroupName: TextView = itemView.findViewById(R.id.tvGroupName)
        val tvMembersCount: TextView = itemView.findViewById(R.id.tvMembersCount)
        val btnJoinGroup: Button = itemView.findViewById(R.id.btnJoinGroup)
    }
}

