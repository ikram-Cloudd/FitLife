package com.example.myapplication

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class WorkoutListActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_workout)

        // 1. Bind UI elements from XML
        val tvTitle = findViewById<TextView>(R.id.tv_workout_title)
        val tvWorkoutsList = findViewById<TextView>(R.id.tv_workouts_list)

        // 2. Receive the mood string that was passed from the first screen
        val selectedMood = intent.getStringExtra("SELECTED_MOOD")

        // 3. Check the mood and display the correct workouts
        if (selectedMood == "energetic") {
            tvTitle.text = "🔥 High Energy Workouts"
            tvWorkoutsList.text = "1. HIIT Cardio (20 mins)\n\n2. Pushups & Pullups\n\n3. Weight Lifting (Heavy)"
        }
        else if (selectedMood == "tired") {
            tvTitle.text = "😌 Relaxing Workouts"
            tvWorkoutsList.text = "1. Full Body Stretching\n\n2. Deep Breathing Yoga\n\n3. Light Walking"
        }
        else if (selectedMood == "calm") {
            tvTitle.text = "🚶‍♂️ Balanced Workouts"
            tvWorkoutsList.text = "1. Brisk Walking (30 mins)\n\n2. Bodyweight Squats\n\n3. Light Jogging"
        }
    }
}
