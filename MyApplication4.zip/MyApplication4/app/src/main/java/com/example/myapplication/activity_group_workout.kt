import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.GroupAdapter
import com.example.myapplication.R

class GroupWorkoutActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_group_workout)


        val dummyGroups = listOf(
            GroupModel("Morning Cardio Warriors", "👥 14 Active Members"),
            GroupModel("Fat Burn Extreme 🔥", "👥 85 Active Members"),
            GroupModel("Yoga & Mindset 😌", "👥 32 Active Members"),
            GroupModel("10K Steps Challenge", "👥 120 Active Members"),
            GroupModel("Home Workout Heroes", "👥 50 Active Members")
        )

        val rvGroups: RecyclerView = findViewById(R.id.rvGroups)


        rvGroups.layoutManager = LinearLayoutManager(this)


        val adapter = GroupAdapter(dummyGroups)
        rvGroups.adapter = adapter
    }
}